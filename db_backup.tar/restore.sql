--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.10
-- Dumped by pg_dump version 11.5 (Ubuntu 11.5-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE auction;
--
-- Name: auction; Type: DATABASE; Schema: -; Owner: yogesh
--

CREATE DATABASE auction WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE auction OWNER TO yogesh;

\connect auction

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auction (
    auction_id integer NOT NULL,
    seller_id integer NOT NULL,
    title text,
    description text,
    initial_bid real NOT NULL,
    exp_date date,
    image_url text,
    vector tsvector
);


ALTER TABLE public.auction OWNER TO admin;

--
-- Name: auction_auction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auction_auction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auction_auction_id_seq OWNER TO admin;

--
-- Name: auction_auction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auction_auction_id_seq OWNED BY public.auction.auction_id;


--
-- Name: bidding; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.bidding (
    auction_id integer NOT NULL,
    user_id integer NOT NULL,
    bid_amount real NOT NULL
);


ALTER TABLE public.bidding OWNER TO admin;

--
-- Name: user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."user" (
    user_id integer NOT NULL,
    email text NOT NULL,
    passroword text NOT NULL,
    jwt_token text,
    "Name" text
);


ALTER TABLE public."user" OWNER TO admin;

--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_user_id_seq OWNER TO admin;

--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.user_user_id_seq OWNED BY public."user".user_id;


--
-- Name: auction auction_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auction ALTER COLUMN auction_id SET DEFAULT nextval('public.auction_auction_id_seq'::regclass);


--
-- Name: user user_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."user" ALTER COLUMN user_id SET DEFAULT nextval('public.user_user_id_seq'::regclass);


--
-- Data for Name: auction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auction (auction_id, seller_id, title, description, initial_bid, exp_date, image_url, vector) FROM stdin;
\.
COPY public.auction (auction_id, seller_id, title, description, initial_bid, exp_date, image_url, vector) FROM '$$PATH$$/3114.dat';

--
-- Data for Name: bidding; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.bidding (auction_id, user_id, bid_amount) FROM stdin;
\.
COPY public.bidding (auction_id, user_id, bid_amount) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."user" (user_id, email, passroword, jwt_token, "Name") FROM stdin;
\.
COPY public."user" (user_id, email, passroword, jwt_token, "Name") FROM '$$PATH$$/3112.dat';

--
-- Name: auction_auction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auction_auction_id_seq', 7, true);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.user_user_id_seq', 1, false);


--
-- Name: auction auction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auction
    ADD CONSTRAINT auction_pkey PRIMARY KEY (auction_id);


--
-- Name: user email; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT email UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: fki_referUserId; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "fki_referUserId" ON public.auction USING btree (seller_id);


--
-- Name: fki_toTheUser; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "fki_toTheUser" ON public.bidding USING btree (auction_id);


--
-- Name: fki_toUsr; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "fki_toUsr" ON public.bidding USING btree (user_id);


--
-- Name: auction referUserId; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auction
    ADD CONSTRAINT "referUserId" FOREIGN KEY (seller_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bidding toTheUser; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bidding
    ADD CONSTRAINT "toTheUser" FOREIGN KEY (auction_id) REFERENCES public.auction(auction_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bidding toUsr; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bidding
    ADD CONSTRAINT "toUsr" FOREIGN KEY (user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

